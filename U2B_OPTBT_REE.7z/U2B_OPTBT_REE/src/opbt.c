/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name	: opbt.c
* Version	: 1.01
* Device(s)	: RH850/U2x
* Description	: This is the main tutorial code.
*******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 10.01.2017 1.00 First Release
*         : 27.02.2017 1.01 for GHS
******************************************************************************/

#pragma ghs section rodata=".OPBT"

const unsigned long opbt[64] = {
	0x00000000,		/* H'FF321380 Reset Vector (PE0)			*/
	0x00000000,		/* H'FF321384 Reset Vector (PE1)			*/
	0x00000000,		/* H'FF321388 Reset Vector (PE2)			*/
	0x00000000,		/* H'FF32138C Reset Vector (PE3)			*/
	0x00000000,		/* H'FF321390 Reset Vector (PE4)			*/
	0x00000000,		/* H'FF321394 Reset Vector (PE5)			*/
	0x00000000,		/* H'FF321398 Reserved                                 	*/
	0x00000000,		/* H'FF32139C Reserved                                 	*/
	0x3FE30010,		/* H'FF3213A0 OPBT0                                    	*/
	0x007B0000,		/* H'FF3213A4 OPBT1                                    	*/
	0x7FFFFFFF,		/* H'FF3213A8 OPBT2                                    	*/
	0xC1FF7EFE,		/* H'FF3213AC OPBT3                                    	*/
	0x0C0C0C0B,		/* H'FF3213B0 OPBT4                                    	*/
	0xFFFFFFFF,		/* H'FF3213B4 Reserved                                 	*/
	0xFFFF3FCF,		/* H'FF3213B8 OPBT6                                    	*/
	0xFFFFFFFF,		/* H'FF3213BC OPBT7                                    	*/
	0xF47FFFFF,		/* H'FF3213C0 OPBT8                                    	*/
	0xFFF03F7F,		/* H'FF3213C4 OPBT9			               	*/
	0xF9FD288E,		/* H'FF3213C8 OPBT10                        	 	*/
	0xEFFFFFFF,		/* H'FF3213CC OPBT11                		       	*/
	0xFFFFFFFD,		/* H'FF3213D0 OPBT12             	         	*/
	0xFFFFFFFF,		/* H'FF3213D4 OPBT13                		      	*/
	0xFFFF880C,		/* H'FF3213D8 OPBT14        		               	*/
	0xFFFF880C,		/* H'FF3213DC OPBT15		                       	*/
	0x74FFFF10,		/* H'FF3213E0 OPBT16					*/
	0xF9AAFCFC,		/* H'FF3213E4 OPBT17					*/
	0xC26BC1CE,		/* H'FF3213E8 OPBT18					*/
	0xFFFFC203,		/* H'FF3213EC OPBT19					*/
	0xCB88FFEF,		/* H'FF3213F0 OPBT20					*/
	0x065503CF,		/* H'FF3213F4 OPBT21					*/
	0xFD94FE31,		/* H'FF3213F8 OPBT22					*/
	0xFFFFFDFC,		/* H'FF3213FC OPBT23					*/
	0xFFFFFFF0,		/* H'FF321400 OPBT24                                 	*/
	0xFFC0F3FF,		/* H'FF321404 OPBT25                                 	*/
	0xFFFF0010,		/* H'FF321408 OPBT26                                 	*/
	0xFFFF0000,		/* H'FF32140C OPBT27                                 	*/
	0xFFFFFFFF,		/* H'FF321410 OPBT28                                 	*/
	0xFFFFFFFF,		/* H'FF321414 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321418 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF32141C Reserved                                 	*/
	0x60000055,		/* H'FF321420 Reserved                                 	*/
	0x60000056,		/* H'FF321424 Reserved                                 	*/
	0xF0F5EC01,		/* H'FF321428 Reserved                                 	*/
	0x0A180001,		/* H'FF32142C Reserved                                 	*/
	0xC184C8FF,		/* H'FF321430 OPBT36                                 	*/
	0x02EFFF55,		/* H'FF321434 OPBT37                                 	*/
	0x00000000,		/* H'FF321438 OPBT38                                 	*/
	0x00000000,		/* H'FF32143C OPBT39                                 	*/
	0xFF00FCFF,		/* H'FF321440 OPBT40                                 	*/
	0xFFFFFFFF,		/* H'FF321444 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321448 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF32144C Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321450 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321454 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321458 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF32145C Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321460 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321464 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321468 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF32146C Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321470 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321474 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF321478 Reserved                                 	*/
	0xFFFFFFFF,		/* H'FF32147C Reserved                                 	*/
};
#pragma ghs section rodata=default

