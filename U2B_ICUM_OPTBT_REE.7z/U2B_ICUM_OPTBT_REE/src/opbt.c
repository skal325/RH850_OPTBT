/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name	: opbt.c
* Version	: 1.01
* Device(s)	: RH850/U2x
* Description	: This is the main tutorial code.
*******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 10.01.2017 1.00 First Release
*         : 27.02.2017 1.01 for GHS
******************************************************************************/

#pragma ghs section rodata=".OPBT"

const unsigned long opbt[8] = {
	0x0FFFFFFF,		/* H'FF322700 ICUM_OPBT0	                                */
	0x007B0000,		/* H'FF322704 ICUM_OPBT1                                    	*/
	0x017F0000,		/* H'FF322708 ICUM_OPBT2                                    	*/
	0xFF280000,		/* H'FF32270C ICUM_OPBT3                                    	*/
	0xFFFD7FC0,		/* H'FF322710 ICUM_OPBT4                                    	*/
	0x01800000,		/* H'FF322714 ICUM_OPTB5                                 	*/
	0xFFFFFFFF,		/* H'FF322718 ICUM_OPBT6                                    	*/
	0xFFFFFFFF,		/* H'FF32271C ICUM_OPBT7                                    	*/
};
#pragma ghs section rodata=default

